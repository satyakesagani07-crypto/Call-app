package com.satya.autodialer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.provider.Settings
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Xml
import android.view.WindowManager
import android.widget.*
import java.math.BigDecimal
import java.util.zip.ZipInputStream

data class Contact(val name: String, val number: String)

class MainActivity : Activity() {
    private var contacts = listOf<Contact>()
    private var idx = 0
    private var running = false
    private var sawOffhook = false
    private val results = HashMap<Int, String>()
    private val options = arrayOf("Interested", "Call back later", "Not interested", "No answer / Busy", "Wrong number")
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var gap: EditText
    private lateinit var maxSec: EditText
    private lateinit var tm: TelephonyManager
    private lateinit var telecom: TelecomManager
    private var legacy: PhoneStateListener? = null
    private var modern: Any? = null
    private val hangup = Runnable { try { telecom.endCall() } catch (_: Exception) {} }
    private val nextCall = Runnable { dial() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        telecom = getSystemService(TELECOM_SERVICE) as TelecomManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; root.addView(this) }
        gap = EditText(this).apply { hint = "Gap between calls (sec)"; setText("5"); inputType = 2 }
        maxSec = EditText(this).apply { hint = "Max seconds per call (auto hang-up)"; setText("30"); inputType = 2 }
        status = TextView(this).apply { text = "Choose an Excel (.xlsx) or CSV file"; textSize = 16f }
        btn("1. Choose Excel / CSV file") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1)
        }
        root.addView(gap); root.addView(maxSec)
        btn("2. Start auto-calling") { start() }
        btn("Stop") { stop("Stopped") }
        btn("Export results (CSV)") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
                putExtra(Intent.EXTRA_TITLE, "call_results.csv") }, 3)
        }
        root.addView(ScrollView(this).apply { addView(status) })
        setContentView(root)
        requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS), 2)
        registerState()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (res != RESULT_OK || d?.data == null) return
        val uri = d.data!!
        if (rc == 3) {
            val sb = StringBuilder("Name,Number,Status\n")
            contacts.forEachIndexed { i, c -> sb.append("\"${c.name}\",\"${c.number}\",\"${results[i] ?: ""}\"\n") }
            contentResolver.openOutputStream(uri)?.use { it.write(sb.toString().toByteArray()) }
            status.text = "Results saved (${results.size} updated)"
            return
        }
        if (rc != 1) return
        try {
            contacts = readSheet(uri)
            idx = 0; results.clear()
            status.text = "Loaded ${contacts.size} numbers. Tap Start."
        } catch (e: Exception) { status.text = "Could not read file: ${e.message}" }
    }

    private fun start() {
        if (contacts.isEmpty()) { status.text = "Load a file first"; return }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Allow phone permissions first"; return }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Allow 'Display over other apps' for this app, then tap Start again"
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        running = true; dial()
    }

    private fun stop(msg: String) {
        running = false; h.removeCallbacks(nextCall); h.removeCallbacks(hangup)
        status.text = "$msg at ${idx}/${contacts.size}"
    }

    private fun dial() {
        if (!running) return
        if (idx >= contacts.size) { stop("Finished all calls"); return }
        val c = contacts[idx]
        status.text = "Calling ${idx + 1}/${contacts.size}: ${c.name} ${c.number}"
        sawOffhook = false
        try {
            telecom.placeCall(Uri.fromParts("tel", c.number, null), Bundle())
        } catch (e: SecurityException) { stop("Permission missing"); return }
        h.postDelayed(hangup, (maxSec.text.toString().toLongOrNull() ?: 30L) * 1000)
    }

    private fun onState(s: Int) {
        if (!running) return
        if (s == TelephonyManager.CALL_STATE_OFFHOOK) sawOffhook = true
        if (s == TelephonyManager.CALL_STATE_IDLE && sawOffhook) {
            sawOffhook = false
            h.removeCallbacks(hangup)
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            h.postDelayed({ askStatus() }, 800)
        }
    }

    private fun askStatus() {
        if (!running || idx >= contacts.size) return
        val c = contacts[idx]
        AlertDialog.Builder(this)
            .setTitle("${c.name} ${c.number}\nCall status?")
            .setCancelable(false)
            .setItems(options) { _, which ->
                results[idx] = options[which]
                idx++
                h.postDelayed(nextCall, (gap.text.toString().toLongOrNull() ?: 5L) * 1000)
            }
            .setNegativeButton("Stop here") { _, _ -> stop("Stopped") }
            .show()
    }

    private fun registerState() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            h.postDelayed({ registerState() }, 2000); return }
        if (modern != null || legacy != null) return
        if (Build.VERSION.SDK_INT >= 31) {
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) = onState(state)
            }
            modern = cb; tm.registerTelephonyCallback(mainExecutor, cb)
        } else {
            @Suppress("DEPRECATION")
            legacy = object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, n: String?) = onState(state)
            }
            @Suppress("DEPRECATION") tm.listen(legacy, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    // ---------- Sheet reading ----------
    private fun readSheet(uri: Uri): List<Contact> {
        val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val rows: List<List<String>> =
            if (bytes.size > 3 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) xlsxRows(bytes)
            else String(bytes).lines().map { it.split(',', ';', '\t').map { c -> c.trim().trim('"') } }
        return rows.mapNotNull { row ->
            val num = row.firstOrNull { c -> c.count { it.isDigit() } in 7..15 && c.all { it.isDigit() || it in "+- ()" } }
            if (num == null) null else Contact(
                row.firstOrNull { it.isNotBlank() && it != num } ?: "", num.filter { it.isDigit() || it == '+' })
        }
    }

    private fun xlsxRows(data: ByteArray): List<List<String>> {
        var shared = ByteArray(0); var sheet = ByteArray(0)
        ZipInputStream(data.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "xl/sharedStrings.xml") shared = z.readBytes()
                if (e.name == "xl/worksheets/sheet1.xml") sheet = z.readBytes()
                e = z.nextEntry
            }
        }
        val strings = ArrayList<String>()
        if (shared.isNotEmpty()) {
            val p = Xml.newPullParser(); p.setInput(shared.inputStream(), null)
            var sb = StringBuilder()
            while (p.next() != 1) {
                if (p.eventType == 2 && p.name == "si") sb = StringBuilder()
                if (p.eventType == 2 && p.name == "t") sb.append(p.nextText())
                if (p.eventType == 3 && p.name == "si") strings.add(sb.toString())
            }
        }
        val rows = ArrayList<List<String>>(); var cur = ArrayList<String>(); var type = ""
        val p = Xml.newPullParser(); p.setInput(sheet.inputStream(), null)
        while (p.next() != 1) {
            if (p.eventType == 2) when (p.name) {
                "row" -> cur = ArrayList()
                "c" -> type = p.getAttributeValue(null, "t") ?: ""
                "v", "t" -> {
                    var v = p.nextText()
                    if (type == "s") v = strings.getOrElse(v.toIntOrNull() ?: -1) { "" }
                    else if (type == "" || type == "n") v = try { BigDecimal(v).toPlainString() } catch (_: Exception) { v }
                    cur.add(v.trim())
                }
            }
            if (p.eventType == 3 && p.name == "row") rows.add(cur)
        }
        return rows
    }
}
